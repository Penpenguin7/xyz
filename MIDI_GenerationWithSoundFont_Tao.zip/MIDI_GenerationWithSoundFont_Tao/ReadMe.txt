Read_Me

1. Download Sound in the following link: http://csound.github.io/download.html
For now the .csd file works on the Mac.

2. You can run MIDI_GenerationWithSoundFont_Tao.csd through CsoundQT, or use command line (Unix): 
cd ./ur current directory of the folder
csound -odac MIDI_GenerationWithSoundFont_Tao.csd

3. The build-in shell for Sound is between <CsOptions> … <\CsOptions> section, using ";" sign on your keyboard to comment a line of code instead using "//".

4. -F flag following with the name of midi file with its .mid format in can will select and play different midi files, see line 7 and 8, comment out one of them to play and switch between 2 different midi files in the folder (midimake.mid and sf_Trumpet.sf2).

5. Sound uses relative path, so all soundfont and midi files has to be in the same folder with Csound file in order to run.