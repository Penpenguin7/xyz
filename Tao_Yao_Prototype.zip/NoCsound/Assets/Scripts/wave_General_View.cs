﻿using UnityEngine;
using System.Collections;

public class wave_General_View : MonoBehaviour {

	int resolution = 30;//reduce sample rate to 60 samples/sec

	public AudioSource audio;
	public LineRenderer lineRend;
	public LineRenderer pointer;
	float[] waveForm;
	float[] samples;
	[SerializeField]
	float len = 50f;
	[SerializeField]
	float amp = 20f;
	Vector3 pointerPos = new Vector3();
	int posIndex = 0;

	void SetUp(){
		resolution = audio.clip.frequency / resolution;
		samples = new float[audio.clip.samples*audio.clip.channels];
		audio.clip.GetData(samples,0);
		waveForm = new float[(samples.Length/resolution)];
		for (int i = 0; i < waveForm.Length; i++)
		{
			waveForm[i] = 0;
			for(int ii = 0; ii<resolution; ii++)
			{	
				waveForm[i] += samples[(i * resolution) + ii];
			}          
			waveForm[i] /= resolution;
		}
		lineRend.positionCount = waveForm.Length;
	}
	void DrawWave(){
		for (int i = -waveForm.Length / 2; i < waveForm.Length / 2; i++) {
			lineRend.SetPosition(i+waveForm.Length/2,new Vector3(i*(float)((float)len/(float)waveForm.Length),waveForm[i+waveForm.Length/2]*amp,0f));
		}
		int current = audio.timeSamples / resolution;
		current *= 2;
		pointerPos = lineRend.GetPosition(current);
		pointer.SetPosition (0,new Vector3(pointerPos.x,0,0));
		pointer.SetPosition (1,new Vector3(pointerPos.x,0.2f,0));
	}

	void Start () {
		SetUp ();
	}


	void Update () {
		DrawWave ();
	}
}
