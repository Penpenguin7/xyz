﻿using UnityEngine;
using System.Collections;

public class Drawline : MonoBehaviour {

	int resolution = 30;//reduce sample rate to 60 samples/sec

	public AudioSource audio;
	//public LineRenderer lineRend;
	float[] waveForm;
	float[] samples;
	/*[SerializeField]
	float len = 50f;
	[SerializeField]
	float amp = 20f;*/

	public struct LineDrawer
	{
		private LineRenderer lineRenderer;
		private float lineSize;

		public LineDrawer(float lineSize = 0.2f)
		{
			GameObject lineObj = new GameObject();
			lineRenderer = lineObj.AddComponent<LineRenderer>();
			//Particles/Additive
			lineRenderer.material = new Material(Shader.Find("Hidden/Internal-Colored"));

			this.lineSize = lineSize;
		}

		private void init(float lineSize = 0.2f)
		{
			if (lineRenderer == null)
			{
				GameObject lineObj = new GameObject("LineObj");
				lineRenderer = lineObj.AddComponent<LineRenderer>();
				//Particles/Additive
				lineRenderer.material = new Material(Shader.Find("Hidden/Internal-Colored"));

				this.lineSize = lineSize;
			}
		}

		//Draws lines through the provided vertices
		public void DrawLineInGameView(Vector3 start, Vector3 end, Color color)
		{
			if (lineRenderer == null)
			{
				init(0.2f);
			}

			//Set color
			lineRenderer.startColor = color;
			lineRenderer.endColor = color;

			//Set width
			lineRenderer.startWidth = lineSize;
			lineRenderer.endWidth = lineSize;

			//Set line count which is 2
			lineRenderer.positionCount = 2;

			//Set the postion of both two lines
			lineRenderer.SetPosition(0, start);
			lineRenderer.SetPosition(1, end);
		}

		public void Destroy()
		{
			if (lineRenderer != null)
			{
				UnityEngine.Object.Destroy(lineRenderer.gameObject);
			}
		}
	}

	LineDrawer[] lineDrawing = new LineDrawer[30828];

	void Start () {
		//How many samples per second for Audio Clip(735)
		resolution = audio.clip.frequency / resolution;
		//samples of entire track
		samples = new float[audio.clip.samples*audio.clip.channels];
		audio.clip.GetData(samples,0);
		//entire track/buffer size = buffer index, The average value of 735 samples stands for one sample now, so our sample rate now is buffer index
		waveForm = new float[(samples.Length/resolution)];
		//go through buffer numbers
		for (int i = 0; i < waveForm.Length; i++)
		{
			waveForm[i] = 0;//this buffer initialize with 0
			//go through every single sample in the buffer
			for(int ii = 0; ii<resolution; ii++)
			{	//samples[(buffer index * buffer size) + the sepecific sample within this current buffer]
				//this buffer = this buffer + every single samples in the buffer (The sum of this 735 values)
				waveForm[i] += Mathf.Abs(samples[(i * resolution) + ii]);//get absolute value
			}          
			//The buffer index = this buffer / buffer size (get the average value from this 735 samples)
			waveForm[i] /= resolution;
		}
	}

	// Update is called once per frame
	void Update () {
		for (int i = 0; i < waveForm.Length - 1; i++)//Go through each samples in our custom sample rate
		{
			//we move 0.01f in world space to the next buffer (custom buffer)
			Vector3 sv = new Vector3(i * .02f, waveForm[i]*10 , 0);//positive value of the wave
			Vector3 ev = new Vector3(i * .02f, -waveForm[i] * 10, 0);//negative value of the wave
			//we are actually drawing pulses
			//Debug.DrawLine(sv, ev, Color.yellow);//(start,end ,color)
			lineDrawing[i].DrawLineInGameView(sv, ev, Color.yellow);
		}
		/*for (int i = -waveForm.Length / 2; i < waveForm.Length / 2; i++) {
			lineRend.SetPosition(i+waveForm.Length/2,new Vector3(i*(float)((float)len/(float)waveForm.Length),waveForm[i+waveForm.Length/2]*amp,0f));
		}*/
		//how many buffers for this entire audio clip? (Not per sec anymore),since we draw line buffers sample by sample
		int current = audio.timeSamples / resolution;//audio.timeSamples = total samples for 2 channel
		current *= 2;//because we have 2 channels

		Vector3 c = new Vector3(current*.02f,0,0);

		Debug.DrawLine(c, c + Vector3.up * 10, Color.red);//start with play location, end on top limit
	}
}
