﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class DSP : MonoBehaviour {

	public AudioSource mySource;
	float[] samples = new float[16384];
	public int blockSize, channel,samplelay;
	int preBlockSize;
	int block, blockleft,sampleSize,blockNum,currentSample;
	public float vol = 1f;
	void setUp(){
		sampleSize = mySource.clip.samples;
		blockNum = sampleSize / samples.Length;
		print (sampleSize);
		print (blockNum);
		channel = 2;
	}

	void Process_Audio(){
		//for(int i = 0;i < blockSize){


		//}

		if (blockSize != preBlockSize) {
			Array.Resize<float> (ref samples,blockSize);
		}
		if (mySource.isPlaying) {
			mySource.GetOutputData (samples, 0);
			for (int i = 0; i < samples.Length; i++) {
				samples [i] = (samples [i]) * vol;
				print (samples [i]);
			}
		}
		preBlockSize = blockSize;
	}
	void Start(){
		setUp ();
	}

	void Update(){
		//Process_Audio();
	}
}
