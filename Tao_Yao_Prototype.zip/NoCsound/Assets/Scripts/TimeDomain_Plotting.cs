﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
public class TimeDomain_Plotting : MonoBehaviour {

	public LineRenderer lineRend;
	//public int sampleSize = 4096;
	//int presampleSize;
	/*[SerializeField]
	float len = 25f;
	[SerializeField]
	float amp = 20f;*/
	public AudioSource source;
	//float[] samples = new float[4096];
	//int clipLength;

	//void Awake(){
		//lineRend.positionCount = sampleSize;
	//}

	void waveform_Plotting(){
		int samplesTotal = source.clip.samples * source.clip.channels;
		lineRend.positionCount = samplesTotal;
		float[] wave = new float[samplesTotal];
		source.clip.GetData (wave,0);
		//source.clip.SetData (wave,0);
		int i = 0;
		while(i < (samplesTotal)){
			//lineRend.SetPosition(i,wave[i]);
			//Debug.Log(wave[i]);
			i++;
		}

		/*if (sampleSize != presampleSize) {
			Array.Resize<float> (ref samples,sampleSize);
			lineRend.positionCount = sampleSize;
		}*/
		/*if (source.isPlaying) {
			source.GetOutputData (samples,0);
			for (int i = -sampleSize / 2; i < sampleSize / 2; i++) {
				lineRend.SetPosition(i+sampleSize/2,new Vector3(i*(float)((float)len/(float)sampleSize),samples[i+sampleSize/2]*amp,0f));
			}
		}*/
		//presampleSize = sampleSize;
	}

	void Start () {
		waveform_Plotting ();
	}
}
